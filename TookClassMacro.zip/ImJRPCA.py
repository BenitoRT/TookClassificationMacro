#This script establishes the connection to R for classifying the parasite

from org.rosuda.REngine import REXP
from org.rosuda.REngine import REXPMismatchException
from org.rosuda.REngine.Rserve import RConnection
from org.rosuda.REngine.Rserve import RserveException

c = RConnection()
#x = c.eval("R.version.string")
#print x.asString()
c.eval("source('ParClass.R')")
p = c.eval("PredictedStage")
p = p.asString()
rt = ResultsTable.getResultsTable()
row=0
rt.setValue("Stage",row,p)
rt.show("Results")
#z = c.eval("R.version.string")
#print z.asString()
c.close()
