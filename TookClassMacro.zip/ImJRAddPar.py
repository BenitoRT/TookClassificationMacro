#This script establishes a connection to R again to update the database

from org.rosuda.REngine import REXP
from org.rosuda.REngine import REXPMismatchException
from org.rosuda.REngine.Rserve import RConnection
from org.rosuda.REngine.Rserve import RserveException

c = RConnection()
#x = c.eval("R.version.string")
#print x.asString()
c.eval("source('CDUpdate.R')")
Trn=getArgument()
if Trn=="y":
     c.eval("source('ClassSuccs.R')")	  
#z = c.eval("R.version.string")
#print z.asString()
c.close()
