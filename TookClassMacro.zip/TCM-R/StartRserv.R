path<-"C:\\ImageJ\\macros\\TCM-R"
setwd(path)
if (!require(dplyr)){
  install.packages(dplyr)
  library(dplyr)
}
if (!require(Rserve)){
  install.packages(Rserve)
  library(Rserve)
}
Rserve()
