#This script calculates some goodnes of fit measures.

# setwd("C:\\ImageJ\\macros\\TCM-R")
library(dplyr)

#Prediction outcome - not essential code. Only for training the database.
#Import Classification Success table and Predicted Stage table
ClassSucks<-read.csv("ClassSucks.csv")
PredSt<-read.csv("PredSt.csv")

#Add the new observed and predicted stage to the existing list
ClassSucks<-bind_rows(ClassSucks,PredSt)

#Goodnes of fit measures
Reg<-lm(PredStage~Stage,data=ClassSucks)
R<-summary(Reg)$r.squared
I<-summary(Reg)$coefficients[1,1]
S<-summary(Reg)$coefficients[2,1]

#Add regression coefficients to Classification Succes
ClassSucks$Rsq[is.na(ClassSucks$Rsq)]<-R
ClassSucks$Int[is.na(ClassSucks$Int)]<-I
ClassSucks$Slp[is.na(ClassSucks$Slp)]<-S

#Add true positives (TP), false negatives (FN), and false positives (FP) to Classification Success
ClassSucks$TP_Ook[is.na(ClassSucks$TP_Ook)]<-(PredSt$Stage==0)*(PredSt$PredStage==0)
ClassSucks$FN_Ook[is.na(ClassSucks$FN_Ook)]<-(PredSt$Stage==0)*(PredSt$PredStage!=0)
ClassSucks$FP_Ook[is.na(ClassSucks$FP_Ook)]<-(PredSt$Stage!=0)*(PredSt$PredStage==0)
ClassSucks$TP_T1[is.na(ClassSucks$TP_T1)]<-(PredSt$Stage==1)*(PredSt$PredStage==1)
ClassSucks$FN_T1[is.na(ClassSucks$FN_T1)]<-(PredSt$Stage==1)*(PredSt$PredStage!=1)
ClassSucks$FP_T1[is.na(ClassSucks$FP_T1)]<-(PredSt$Stage!=1)*(PredSt$PredStage==1)
ClassSucks$TP_T2[is.na(ClassSucks$TP_T2)]<-(PredSt$Stage==2)*(PredSt$PredStage==2)
ClassSucks$FN_T2[is.na(ClassSucks$FN_T2)]<-(PredSt$Stage==2)*(PredSt$PredStage!=2)
ClassSucks$FP_T2[is.na(ClassSucks$FP_T2)]<-(PredSt$Stage!=2)*(PredSt$PredStage==2)
ClassSucks$TP_T3[is.na(ClassSucks$TP_T3)]<-(PredSt$Stage==3)*(PredSt$PredStage==3)
ClassSucks$FN_T3[is.na(ClassSucks$FN_T3)]<-(PredSt$Stage==3)*(PredSt$PredStage!=3)
ClassSucks$FP_T3[is.na(ClassSucks$FP_T3)]<-(PredSt$Stage!=3)*(PredSt$PredStage==3)
ClassSucks$TP_T4[is.na(ClassSucks$TP_T4)]<-(PredSt$Stage==4)*(PredSt$PredStage==4)
ClassSucks$FN_T4[is.na(ClassSucks$FN_T4)]<-(PredSt$Stage==4)*(PredSt$PredStage!=4)
ClassSucks$FP_T4[is.na(ClassSucks$FP_T4)]<-(PredSt$Stage!=4)*(PredSt$PredStage==4)
ClassSucks$TP_T5[is.na(ClassSucks$TP_T5)]<-(PredSt$Stage==5)*(PredSt$PredStage==5)
ClassSucks$FN_T5[is.na(ClassSucks$FN_T5)]<-(PredSt$Stage==5)*(PredSt$PredStage!=5)
ClassSucks$FP_T5[is.na(ClassSucks$FP_T5)]<-(PredSt$Stage!=5)*(PredSt$PredStage==5)
ClassSucks$TP_Ooc[is.na(ClassSucks$TP_Ooc)]<-(PredSt$Stage==6)*(PredSt$PredStage==6)
ClassSucks$FN_Ooc[is.na(ClassSucks$FN_Ooc)]<-(PredSt$Stage==6)*(PredSt$PredStage!=6)
ClassSucks$FP_Ooc[is.na(ClassSucks$FP_Ooc)]<-(PredSt$Stage!=6)*(PredSt$PredStage==6)

#Precision, recall, and Jaccard index (Intersection over Union)
ClassSucks$TP_All[is.na(ClassSucks$TP_All)]<-sum(ClassSucks[nrow(ClassSucks),6],
                                                 ClassSucks[nrow(ClassSucks),9],
                                                 ClassSucks[nrow(ClassSucks),12],
                                                 ClassSucks[nrow(ClassSucks),15],
                                                 ClassSucks[nrow(ClassSucks),18],
                                                 ClassSucks[nrow(ClassSucks),21],
                                                 ClassSucks[nrow(ClassSucks),24])
ClassSucks$FN_All[is.na(ClassSucks$FN_All)]<-sum(ClassSucks[nrow(ClassSucks),7],
                                                 ClassSucks[nrow(ClassSucks),10],
                                                 ClassSucks[nrow(ClassSucks),13],
                                                 ClassSucks[nrow(ClassSucks),16],
                                                 ClassSucks[nrow(ClassSucks),19],
                                                 ClassSucks[nrow(ClassSucks),22],
                                                 ClassSucks[nrow(ClassSucks),25])
ClassSucks$FP_All[is.na(ClassSucks$FP_All)]<-sum(ClassSucks[nrow(ClassSucks),8],
                                                 ClassSucks[nrow(ClassSucks),11],
                                                 ClassSucks[nrow(ClassSucks),14],
                                                 ClassSucks[nrow(ClassSucks),17],
                                                 ClassSucks[nrow(ClassSucks),20],
                                                 ClassSucks[nrow(ClassSucks),23],
                                                 ClassSucks[nrow(ClassSucks),26])
ClassSucks$P_Ook[is.na(ClassSucks$P_Ook)]<-sum(ClassSucks$TP_Ook)/sum(ClassSucks$TP_Ook,ClassSucks$FP_Ook)
ClassSucks$R_Ook[is.na(ClassSucks$R_Ook)]<-sum(ClassSucks$TP_Ook)/sum(ClassSucks$TP_Ook,ClassSucks$FN_Ook)
ClassSucks$IoU_Ook[is.na(ClassSucks$IoU_Ook)]<-sum(ClassSucks$TP_Ook)/sum(ClassSucks$TP_Ook,ClassSucks$FP_Ook,ClassSucks$FN_Ook)
ClassSucks$P_T1[is.na(ClassSucks$P_T1)]<-sum(ClassSucks$TP_T1)/sum(ClassSucks$TP_T1,ClassSucks$FP_T1)
ClassSucks$R_T1[is.na(ClassSucks$R_T1)]<-sum(ClassSucks$TP_T1)/sum(ClassSucks$TP_T1,ClassSucks$FN_T1)
ClassSucks$IoU_T1[is.na(ClassSucks$IoU_T1)]<-sum(ClassSucks$TP_T1)/sum(ClassSucks$TP_T1,ClassSucks$FP_T1,ClassSucks$FN_T1)
ClassSucks$P_T2[is.na(ClassSucks$P_T2)]<-sum(ClassSucks$TP_T2)/sum(ClassSucks$TP_T2,ClassSucks$FP_T2)
ClassSucks$R_T2[is.na(ClassSucks$R_T2)]<-sum(ClassSucks$TP_T2)/sum(ClassSucks$TP_T2,ClassSucks$FN_T2)
ClassSucks$IoU_T2[is.na(ClassSucks$IoU_T2)]<-sum(ClassSucks$TP_T2)/sum(ClassSucks$TP_T2,ClassSucks$FP_T2,ClassSucks$FN_T2)
ClassSucks$P_T3[is.na(ClassSucks$P_T3)]<-sum(ClassSucks$TP_T3)/sum(ClassSucks$TP_T3,ClassSucks$FP_T3)
ClassSucks$R_T3[is.na(ClassSucks$R_T3)]<-sum(ClassSucks$TP_T3)/sum(ClassSucks$TP_T3,ClassSucks$FN_T3)
ClassSucks$IoU_T3[is.na(ClassSucks$IoU_T3)]<-sum(ClassSucks$TP_T3)/sum(ClassSucks$TP_T3,ClassSucks$FP_T3,ClassSucks$FN_T3)
ClassSucks$P_T4[is.na(ClassSucks$P_T4)]<-sum(ClassSucks$TP_T4)/sum(ClassSucks$TP_T4,ClassSucks$FP_T4)
ClassSucks$R_T4[is.na(ClassSucks$R_T4)]<-sum(ClassSucks$TP_T4)/sum(ClassSucks$TP_T4,ClassSucks$FN_T4)
ClassSucks$IoU_T4[is.na(ClassSucks$IoU_T4)]<-sum(ClassSucks$TP_T4)/sum(ClassSucks$TP_T4,ClassSucks$FP_T4,ClassSucks$FN_T4)
ClassSucks$P_T5[is.na(ClassSucks$P_T5)]<-sum(ClassSucks$TP_T5)/sum(ClassSucks$TP_T5,ClassSucks$FP_T5)
ClassSucks$R_T5[is.na(ClassSucks$R_T5)]<-sum(ClassSucks$TP_T5)/sum(ClassSucks$TP_T5,ClassSucks$FN_T5)
ClassSucks$IoU_T5[is.na(ClassSucks$IoU_T5)]<-sum(ClassSucks$TP_T5)/sum(ClassSucks$TP_T5,ClassSucks$FP_T5,ClassSucks$FN_T5)
ClassSucks$P_Ooc[is.na(ClassSucks$P_Ooc)]<-sum(ClassSucks$TP_Ooc)/sum(ClassSucks$TP_Ooc,ClassSucks$FP_Ooc)
ClassSucks$R_Ooc[is.na(ClassSucks$R_Ooc)]<-sum(ClassSucks$TP_Ooc)/sum(ClassSucks$TP_Ooc,ClassSucks$FN_Ooc)
ClassSucks$IoU_Ooc[is.na(ClassSucks$IoU_Ooc)]<-sum(ClassSucks$TP_Ooc)/sum(ClassSucks$TP_Ooc,ClassSucks$FP_Ooc,ClassSucks$FN_Ooc)
ClassSucks$P_All[is.na(ClassSucks$P_All)]<-sum(ClassSucks$TP_All)/sum(ClassSucks$TP_All,ClassSucks$FP_All)
ClassSucks$R_All[is.na(ClassSucks$R_All)]<-sum(ClassSucks$TP_All)/sum(ClassSucks$TP_All,ClassSucks$FN_All)
ClassSucks$IoU_All[is.na(ClassSucks$IoU_All)]<-sum(ClassSucks$TP_All)/sum(ClassSucks$TP_All,ClassSucks$FP_All,ClassSucks$FN_All)

#Save Updated ClassSucks table
write.csv(ClassSucks, file="ClassSucks.csv", row.names=FALSE)

# Plots
# plot(ClassSucks$Stage,
#      ClassSucks$PredStage,
#      type="p",
#      pch=19,
#      col="goldenrod1",
#      cex=0.8,
#      ylab="Predicted Stage",
#      xlab="Visual Stage Assignment",
#      cex.lab=1.4,
#      cex.axis=1.2)
# abline(I,
#        S,
#        lwd=3)
# par(mai=c(1,0.9,0.8,0.4))
# plot(rownames(ClassSucks),
#      ClassSucks$Rsq,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab=expression(R^{2}))
# points(rownames(ClassSucks),
#        ClassSucks$Rsq,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$Int,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Intercept")
# points(rownames(ClassSucks),
#        ClassSucks$Int,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$Slp,
#      type="l",
#      lwd=3,
#      cex.lab=1.4,
#      cex.axis=1.2,
#      xlab="Number of Parasites in Training Base",
#      ylab="Slope")
# points(rownames(ClassSucks),
#        ClassSucks$Slp,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$P_Ook,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_Ook,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_Ook,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_Ook,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_Ook,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_Ook,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$P_T1,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_T1,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_T1,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_T1,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_T1,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_T1,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$P_T2,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_T2,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_T2,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_T2,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_T2,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_T2,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$P_T3,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_T3,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_T3,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_T3,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_T3,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_T3,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$P_T4,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_T4,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_T4,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_T4,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_T4,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_T4,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$P_T5,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_T5,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_T5,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_T5,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_T5,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_T5,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$P_Ooc,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_Ooc,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_Ooc,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_Ooc,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_Ooc,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_Ooc,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# 
# plot(rownames(ClassSucks),
#      ClassSucks$P_All,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Precision")
# points(rownames(ClassSucks),
#        ClassSucks$P_All,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$R_All,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Recall")
# points(rownames(ClassSucks),
#        ClassSucks$R_All,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")
# plot(rownames(ClassSucks),
#      ClassSucks$IoU_All,type="l",
#      lwd=3,
#      cex.axis=1.2,
#      cex.lab=1.4,
#      xlab="Number of Parasites in Training Base",
#      ylab="Jaccard index")
# points(rownames(ClassSucks),
#        ClassSucks$IoU_All,
#        type="p",
#        pch=19,
#        cex=0.8,
#        col="goldenrod1")


#Success in classification
CAss<-read.csv("PredStageCorrectAssig.csv")
CAss$Success<-NA
CAss$Assig<-NA
attach(CAss)

Ook_Ook<-sum((ClassSucks$Stage==0)*(ClassSucks$PredStage==0))
Ook_T1<-sum((ClassSucks$Stage==0)*(ClassSucks$PredStage==1))
Ook_T2<-sum((ClassSucks$Stage==0)*(ClassSucks$PredStage==2))
Ook_T3<-sum((ClassSucks$Stage==0)*(ClassSucks$PredStage==3))
Ook_T4<-sum((ClassSucks$Stage==0)*(ClassSucks$PredStage==4))
Ook_T5<-sum((ClassSucks$Stage==0)*(ClassSucks$PredStage==5))
Ook_Ooc<-sum((ClassSucks$Stage==0)*(ClassSucks$PredStage==6))
T1_Ook<-sum((ClassSucks$Stage==1)*(ClassSucks$PredStage==0))
T1_T1<-sum((ClassSucks$Stage==1)*(ClassSucks$PredStage==1))
T1_T2<-sum((ClassSucks$Stage==1)*(ClassSucks$PredStage==2))
T1_T3<-sum((ClassSucks$Stage==1)*(ClassSucks$PredStage==3))
T1_T4<-sum((ClassSucks$Stage==1)*(ClassSucks$PredStage==4))
T1_T5<-sum((ClassSucks$Stage==1)*(ClassSucks$PredStage==5))
T1_Ooc<-sum((ClassSucks$Stage==1)*(ClassSucks$PredStage==6))
T2_Ook<-sum((ClassSucks$Stage==2)*(ClassSucks$PredStage==0))
T2_T1<-sum((ClassSucks$Stage==2)*(ClassSucks$PredStage==1))
T2_T2<-sum((ClassSucks$Stage==2)*(ClassSucks$PredStage==2))
T2_T3<-sum((ClassSucks$Stage==2)*(ClassSucks$PredStage==3))
T2_T4<-sum((ClassSucks$Stage==2)*(ClassSucks$PredStage==4))
T2_T5<-sum((ClassSucks$Stage==2)*(ClassSucks$PredStage==5))
T2_Ooc<-sum((ClassSucks$Stage==2)*(ClassSucks$PredStage==6))
T3_Ook<-sum((ClassSucks$Stage==3)*(ClassSucks$PredStage==0))
T3_T1<-sum((ClassSucks$Stage==3)*(ClassSucks$PredStage==1))
T3_T2<-sum((ClassSucks$Stage==3)*(ClassSucks$PredStage==2))
T3_T3<-sum((ClassSucks$Stage==3)*(ClassSucks$PredStage==3))
T3_T4<-sum((ClassSucks$Stage==3)*(ClassSucks$PredStage==4))
T3_T5<-sum((ClassSucks$Stage==3)*(ClassSucks$PredStage==5))
T3_Ooc<-sum((ClassSucks$Stage==3)*(ClassSucks$PredStage==6))
T4_Ook<-sum((ClassSucks$Stage==4)*(ClassSucks$PredStage==0))
T4_T1<-sum((ClassSucks$Stage==4)*(ClassSucks$PredStage==1))
T4_T2<-sum((ClassSucks$Stage==4)*(ClassSucks$PredStage==2))
T4_T3<-sum((ClassSucks$Stage==4)*(ClassSucks$PredStage==3))
T4_T4<-sum((ClassSucks$Stage==4)*(ClassSucks$PredStage==4))
T4_T5<-sum((ClassSucks$Stage==4)*(ClassSucks$PredStage==5))
T4_Ooc<-sum((ClassSucks$Stage==4)*(ClassSucks$PredStage==6))
T5_Ook<-sum((ClassSucks$Stage==5)*(ClassSucks$PredStage==0))
T5_T1<-sum((ClassSucks$Stage==5)*(ClassSucks$PredStage==1))
T5_T2<-sum((ClassSucks$Stage==5)*(ClassSucks$PredStage==2))
T5_T3<-sum((ClassSucks$Stage==5)*(ClassSucks$PredStage==3))
T5_T4<-sum((ClassSucks$Stage==5)*(ClassSucks$PredStage==4))
T5_T5<-sum((ClassSucks$Stage==5)*(ClassSucks$PredStage==5))
T5_Ooc<-sum((ClassSucks$Stage==5)*(ClassSucks$PredStage==6))
Ooc_Ook<-sum((ClassSucks$Stage==6)*(ClassSucks$PredStage==0))
Ooc_T1<-sum((ClassSucks$Stage==6)*(ClassSucks$PredStage==1))
Ooc_T2<-sum((ClassSucks$Stage==6)*(ClassSucks$PredStage==2))
Ooc_T3<-sum((ClassSucks$Stage==6)*(ClassSucks$PredStage==3))
Ooc_T4<-sum((ClassSucks$Stage==6)*(ClassSucks$PredStage==4))
Ooc_T5<-sum((ClassSucks$Stage==6)*(ClassSucks$PredStage==5))
Ooc_Ooc<-sum((ClassSucks$Stage==6)*(ClassSucks$PredStage==6))

CAss$Success<-c(Ook_Ook,Ook_T1,Ook_T2,Ook_T3,Ook_T4,Ook_T5,Ook_Ooc,T1_Ook,T1_T1,T1_T2,T1_T3,T1_T4,T1_T5,T1_Ooc,T2_Ook,T2_T1,T2_T2,T2_T3,T2_T4,T2_T5,T2_Ooc,T3_Ook,T3_T1,T3_T2,T3_T3,T3_T4,T3_T5,T3_Ooc,T4_Ook,T4_T1,T4_T2,T4_T3,T4_T4,T4_T5,T4_Ooc,T5_Ook,T5_T1,T5_T2,T5_T3,T5_T4,T5_T5,T5_Ooc,Ooc_Ook,Ooc_T1,Ooc_T2,Ooc_T3,Ooc_T4,Ooc_T5,Ooc_Ooc)
SOok<-sum(Ook_Ook,
          Ook_T1,
          Ook_T2,
          Ook_T3,
          Ook_T4,
          Ook_T5,
          Ook_Ooc)
ST1<-sum(T1_Ook,
         T1_T1,
         T1_T2,
         T1_T3,
         T1_T4,
         T1_T5,
         T1_Ooc)
ST2<-sum(T2_Ook,
         T2_T1,
         T2_T2,
         T2_T3,
         T2_T4,
         T2_T5,
         T2_Ooc)
ST3<-sum(T3_Ook,
         T3_T1,
         T3_T2,
         T3_T3,
         T3_T4,
         T3_T5,
         T3_Ooc)
ST4<-sum(T4_Ook,
         T4_T1,
         T4_T2,
         T4_T3,
         T4_T4,
         T4_T5,
         T4_Ooc)
ST5<-sum(T5_Ook,
         T5_T1,
         T5_T2,
         T5_T3,
         T5_T4,
         T5_T5,
         T5_Ooc)
SOoc<-sum(Ooc_Ook,
          Ooc_T1,
          Ooc_T2,
          Ooc_T3,
          Ooc_T4,
          Ooc_T5,
          Ooc_Ooc)

CAss$Assig<-c((Ook_Ook*100)/(SOok),
              (Ook_T1*100)/(SOok),
              (Ook_T2*100)/(SOok),
              (Ook_T3*100)/(SOok),
              (Ook_T4*100)/(SOok),
              (Ook_T5*100)/(SOok),
              (Ook_Ooc*100)/(SOok),
              (T1_Ook*100)/(ST1),
              (T1_T1*100)/(ST1),
              (T1_T2*100)/(ST1),
              (T1_T3*100)/(ST1),
              (T1_T4*100)/(ST1),
              (T1_T5*100)/(ST1),
              (T1_Ooc*100)/(ST1),
              (T2_Ook*100)/(ST2),
              (T2_T1*100)/(ST2),
              (T2_T2*100)/(ST2),
              (T2_T3*100)/(ST2),
              (T2_T4*100)/(ST2),
              (T2_T5*100)/(ST2),
              (T2_Ooc*100)/(ST2),
              (T3_Ook*100)/(ST3),
              (T3_T1*100)/(ST3),
              (T3_T2*100)/(ST3),
              (T3_T3*100)/(ST3),
              (T3_T4*100)/(ST3),
              (T3_T5*100)/(ST3),
              (T3_Ooc*100)/(ST3),
              (T4_Ook*100)/(ST4),
              (T4_T1*100)/(ST4),
              (T4_T2*100)/(ST4),
              (T4_T3*100)/(ST4),
              (T4_T4*100)/(ST4),
              (T4_T5*100)/(ST4),
              (T4_Ooc*100)/(ST4),
              (T5_Ook*100)/(ST5),
              (T5_T1*100)/(ST5),
              (T5_T2*100)/(ST5),
              (T5_T3*100)/(ST5),
              (T5_T4*100)/(ST5),
              (T5_T5*100)/(ST5),
              (T5_Ooc*100)/(ST5),
              (Ooc_Ook*100)/(SOoc),
              (Ooc_T1*100)/(SOoc),
              (Ooc_T2*100)/(SOoc),
              (Ooc_T3*100)/(SOoc),
              (Ooc_T4*100)/(SOoc),
              (Ooc_T5*100)/(SOoc),
              (Ooc_Ooc*100)/(SOoc))

write.csv(CAss,file="PredStageCorrectAssig.csv",row.names=FALSE)

#Plot Stage vs Predicted stage
# par(mai=c(1.4,1.4,0.5,0.5))
# par(mgp=c(5, 1, 0))
# with(CAss,
#      symbols(x=CAss$Stage,
#              y=CAss$PredStage,
#              circles=CAss$Assig,
#              inches=1/3,
#              bg="#666699",
#              fg=NULL,
#              xaxt='n',
#              yaxt='n',
#              xlab="Stage assignment by the trainer",
#              ylab="Stage assignment by the macro",
#              cex.lab=1.4))
# legend(-0.8,6.4,
#        legend=c(1,20,40,60,80,100),
#        horiz=TRUE,
#        pch=21,
#        bty="n",
#        col="white",
#        pt.bg="#666699",
#        pt.cex=c(1,2,4,6,8,10),
#        text.font=2)
# axis(1,at=0:6,labels=c("Ookinete","Took 1","Took 2","Took 3","Took 4","Took 5","Oocyst"),cex.axis=1.2)
# axis(2,at=0:6,labels=c("Ookinete","Took 1","Took 2","Took 3","Took 4","Took 5","Oocyst"),cex.axis=1.2,las=1)

#  Calculate Adjusted Rand Index
# library(mclust)
# ObSt<-ClassSucks$Stage
# PredSt<-ClassSucks$PredStage
# FObSt<-ObSt[1:331]
# FPredSt<-PredSt[1:331]
# MObSt<-ObSt[1:350]
# MPredSt<-PredSt[1:350]
# LObSt<-ObSt[1:706]
# LPredSt<-PredSt[1:706]
# adjustedRandIndex(FObSt,FPredSt)
# adjustedRandIndex(MObSt,MPredSt)
# adjustedRandIndex(LObSt,LPredSt)
# adjustedRandIndex(ObSt,PredSt)
