#This script performs the PCA on the training database, predicts the PC's of an incomming parasite, and assigns a stage to it.

# setwd("C:\\ImageJ\\macros\\TCM-R")
#ST<-Sys.time()

#Import Classification Data table and Parasite Measurement table
ClassData<-read.csv("ClassData.csv")
ParMeas<-read.csv("ParMeas.csv")

#Create the data frame of the Parasite Measurements
if(ParMeas[7,37]==0){
  DistCenToBrch=0
  DistCenToJun=0
}else{
  DistCenToBrch=sqrt(((ParMeas[6,8]-ParMeas[2,8])^2)+((ParMeas[6,9]-ParMeas[2,9])^2))
  DistCenToJun=sqrt(((ParMeas[7,8]-ParMeas[2,8])^2)+((ParMeas[7,9]-ParMeas[2,9])^2))
}
if(ParMeas[6,36]==0){
  SkBrch=1
}else{
  SkBrch=ParMeas[6,36]
}
ParData<-data.frame(ParArea=ParMeas[2,3],
                    NucPos=ParMeas[3,4],
                    NucArea=ParMeas[3,3],
                    PigPos=ParMeas[4,4],
                    PigArea=ParMeas[4,3],
                    PigSpots=ParMeas[4,34],
                    Perim=ParMeas[2,12],
                    Circ=ParMeas[2,20],
                    AR=ParMeas[2,29],
                    Round=ParMeas[2,30],
                    Solidity=ParMeas[2,31],
                    Mayor=ParMeas[2,17],
                    Minor=ParMeas[2,18],
                    SkLngth=ParMeas[5,35],
                    SkBrch=SkBrch,
                    SkJun=ParMeas[7,37],
                    Feret=ParMeas[2,21],
                    #MinF=ParMeas[2,27],
                    BBLngth=ParMeas[1,32],
                    BBWdth=ParMeas[1,33],
                    #CX=ParMeas[2,8],
                    #CY=ParMeas[2,9],
                    #SkBX=ParMeas[6,8],
                    #SkBY=ParMeas[6,9],
                    #SkJX=ParMeas[7,8],
                    #SkJY=ParMeas[7,9],
                    DCTB=DistCenToBrch,
                    DCTJ=DistCenToJun)

#Create new columns
ClassData$Eccentricity<-NA
ClassData$LinEcc<-NA
#ClassData$FoMF<-NA
ClassData$BBLoBBW<-NA
ClassData$SkLoSkB<-NA
#ClassData$DistCenToBrch<-NA
#ClassData$DistCenToJun<-NA
ParData$Eccentricity<-NA
ParData$LinEcc<-NA
#ParData$FoMF<-NA
ParData$BBLoBBW<-NA
ParData$SkLoSkB<-NA
#ParData$DistCenToBrch<-NA
#ParData$DistCenToJun<-NA
attach(ClassData)
attach(ParData)

#Fill the columns with calculated data
ClassData$Eccentricity<-sqrt(1-((ClassData$Minor^2)/(ClassData$Mayor^2))) #Eccentricity of the ellipse
ClassData$LinEcc<-sqrt((ClassData$Mayor^2)-(ClassData$Minor^2)) #Linear Eccentricity (otherwise, the length from the center to one focal point)
#ClassData$FoMF<-ClassData$Feret/ClassData$MinF #Maximum parasite lenght over maximum parasite width
ClassData$BBLoBBW<-ClassData$BBLngth/ClassData$BBWdth #Length of the fitting bounding box over width
ClassData$SkLoSkB<-ClassData$SkLngth/ClassData$SkBrch 
ParData$Eccentricity<-sqrt(1-((ParData$Minor^2)/(ParData$Mayor^2)))
ParData$LinEcc<-sqrt((ParData$Mayor^2)-(ParData$Minor^2))
#ParData$FoMF<-ParData$Feret/ParData$MinF
ParData$BBLoBBW<-ParData$BBLngth/ParData$BBWdth
ParData$SkLoSkB<-ParData$SkLngth/ParData$SkBrch 

#Shift colum order
ClassData<-ClassData[,c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,25,26,22)]

#Define the vectors
CD.stages<-ClassData[,26]
CD.data<-ClassData[,1:25]

#Principal component analysis
CD.pca<-prcomp(CD.data,center=TRUE,scale.=TRUE)

#Summary and ploting.
# print(CD.pca)
# plot(CD.pca,type="l")
# summary(CD.pca)
# library(devtools)
# library(ggbiplot)
# id1<-which(CD.stages=="Ookinete")
# id2<-which(CD.stages=="Took_1")
# id3<-which(CD.stages=="Took_2")
# id4<-which(CD.stages=="Took_3")
# id5<-which(CD.stages=="Took_4")
# id6<-which(CD.stages=="Took_5")
# id7<-which(CD.stages=="Oocyst")
# clrs<-NULL
# clrs[id1]<-"#FF0000"
# clrs[id2]<-"#FFCC00"
# clrs[id3]<-"#FFFF00"
# clrs[id4]<-"#99CC00"
# clrs[id5]<-"#99CCFF"
# clrs[id6]<-"#3366FF"
# clrs[id7]<-"#CC99FF"
# g<-ggbiplot(CD.pca,choices=c(1,2),obs.scale=1,var.scale=1,groups=CD.stages,ellipse=TRUE,alpha=1,var.axes=T)
# g<-g+scale_color_manual(values=c("#CC99FF","#FF5555","#FFd738","#FFFF45","#99CC00","#99CCFF","#6088fe"))
# g<-g+theme(legend.direction='horizontal',legend.position='none',axis.title.x=element_text(size=20),axis.text.x=element_text(size=16),axis.title.y=element_text(size=20),axis.text.y=element_text(size=16))
# g<-g+xlim(-8,7)
# g<-g+ylim(-6,6)
# print(g)
# library(rgl)
# plot3d(CD.pca$x, col=clrs, size=8)
# play3d(spin3d(axis=c(1,1,1),rpm=4),duration=15)

#Make PCA results a table. The PC of the stages are stored as x.
StagesPCs<-CD.pca$x
StagesPCs<-data.frame(StagesPCs)
StagesPCs$Stage<-NA
StagesPCs$Stage<-CD.stages

#Split the stages with their corresponding PC's
OokPCs<-subset(StagesPCs, Stage=="Ookinete")
T1PCs<-subset(StagesPCs, Stage=="Took_1")
T2PCs<-subset(StagesPCs, Stage=="Took_2")
T3PCs<-subset(StagesPCs, Stage=="Took_3")
T4PCs<-subset(StagesPCs, Stage=="Took_4")
T5PCs<-subset(StagesPCs, Stage=="Took_5")
OocPCs<-subset(StagesPCs, Stage=="Oocyst")

#Calculate the centroid of each stage cluster.
OokCen<-data.frame(PC1=mean(OokPCs$PC1),
                   PC2=mean(OokPCs$PC2),
                   PC3=mean(OokPCs$PC3),
                   PC4=mean(OokPCs$PC4),
                   PC5=mean(OokPCs$PC5),
                   PC6=mean(OokPCs$PC6),
                   PC7=mean(OokPCs$PC7),
                   PC8=mean(OokPCs$PC8),
                   PC9=mean(OokPCs$PC9),
                   PC10=mean(OokPCs$PC10))
T1Cen<-data.frame(PC1=mean(T1PCs$PC1),
                  PC2=mean(T1PCs$PC2),
                  PC3=mean(T1PCs$PC3),
                  PC4=mean(T1PCs$PC4),
                  PC5=mean(T1PCs$PC5),
                  PC6=mean(T1PCs$PC6), 
                  PC7=mean(T1PCs$PC7),
                  PC8=mean(T1PCs$PC8),
                  PC9=mean(T1PCs$PC9),
                  PC10=mean(T1PCs$PC10))
T2Cen<-data.frame(PC1=mean(T2PCs$PC1),
                  PC2=mean(T2PCs$PC2),
                  PC3=mean(T2PCs$PC3),
                  PC4=mean(T2PCs$PC4),
                  PC5=mean(T2PCs$PC5),
                  PC6=mean(T2PCs$PC6), 
                  PC7=mean(T2PCs$PC7),
                  PC8=mean(T2PCs$PC8),
                  PC9=mean(T2PCs$PC9),
                  PC10=mean(T2PCs$PC10))
T3Cen<-data.frame(PC1=mean(T3PCs$PC1),
                  PC2=mean(T3PCs$PC2), 
                  PC3=mean(T3PCs$PC3),
                  PC4=mean(T3PCs$PC4),
                  PC5=mean(T3PCs$PC5),
                  PC6=mean(T3PCs$PC6),
                  PC7=mean(T3PCs$PC7),
                  PC8=mean(T3PCs$PC8),
                  PC9=mean(T3PCs$PC9),
                  PC10=mean(T3PCs$PC10))
T4Cen<-data.frame(PC1=mean(T4PCs$PC1),
                  PC2=mean(T4PCs$PC2),
                  PC3=mean(T4PCs$PC3),
                  PC4=mean(T4PCs$PC4),
                  PC5=mean(T4PCs$PC5),
                  PC6=mean(T4PCs$PC6),
                  PC7=mean(T4PCs$PC7),
                  PC8=mean(T4PCs$PC8),
                  PC9=mean(T4PCs$PC9),
                  PC10=mean(T4PCs$PC10))
T5Cen<-data.frame(PC1=mean(T5PCs$PC1),
                  PC2=mean(T5PCs$PC2),
                  PC3=mean(T5PCs$PC3),
                  PC4=mean(T5PCs$PC4),
                  PC5=mean(T5PCs$PC5),
                  PC6=mean(T5PCs$PC6),
                  PC7=mean(T5PCs$PC7),
                  PC8=mean(T5PCs$PC8),
                  PC9=mean(T5PCs$PC9),
                  PC10=mean(T5PCs$PC10))
OocCen<-data.frame(PC1=mean(OocPCs$PC1),
                   PC2=mean(OocPCs$PC2),
                   PC3=mean(OocPCs$PC3),
                   PC4=mean(OocPCs$PC4),
                   PC5=mean(OocPCs$PC5), 
                   PC6=mean(OocPCs$PC6),
                   PC7=mean(OocPCs$PC7),
                   PC8=mean(OocPCs$PC8),
                   PC9=mean(OocPCs$PC9),
                   PC10=mean(OocPCs$PC10))

#Create table of the stages centroids.
StagesCen<-rbind(OokCen, T1Cen, T2Cen, T3Cen, T4Cen, T5Cen, OocCen)

#Ploting
# myCol<-c("#FF0000","#FFCC00","#FFFF00","#99CC00","#99CCFF","#3366FF","#CC99FF")
# par(mar=c(5,5.5,4,2))
# plot(StagesCen$PC1,StagesCen$PC2,col=myCol,pch=19,cex=3.6,xlab="PC1",ylab="PC2",cex.lab=2,bty="n",xaxt="n",yaxt="n",xlim=c(-5.8,4),ylim=c(-2,2))
# axis(side=1,lwd=3,cex.axis=1.5)
# axis(side=2,lwd=3,cex.axis=1.5)
# plot(StagesCen$PC1,StagesCen$PC3,col=myCol,pch=19,cex=3.6,xlab="PC1",ylab="PC3",cex.lab=2,bty="n",xaxt="n",yaxt="n",xlim=c(-5.8,4),ylim=c(-2,2))
# axis(side=1,lwd=3,cex.axis=1.5)
# axis(side=2,lwd=3,cex.axis=1.5)
# plot(StagesCen$PC2,StagesCen$PC3,col=myCol,pch=19,cex=3.6,xlab="PC2",ylab="PC3",cex.lab=2,bty="n",xaxt="n",yaxt="n",xlim=c(-2,2),ylim=c(-2,2))
# axis(side=1,lwd=3,cex.axis=1.5)
# axis(side=2,lwd=3,cex.axis=1.5)
# legend(-1.86,1.35,c("Ookinete","Took 1","Took 2","Took 3", "Took 4","Took 5","Oocyst"),col=myCol,pch=19,horiz=TRUE)
# plot3d(StagesCen, col=myCol, size=14)
# play3d(spin3d(axis=c(0,0,1),rpm=4),duration=15)
# library(magick)
# movie3d(
#   movie="CentroidsAnimation",
#   spin3d(axis=c(0,0,1),rpm=4),
#   duration=15,
#   dir="C:\\Users\\b_rec\\OneDrive\\Documents\\Biologia\\Plasmodium\\DiferenciacionOocRedox\\AlgoritmoIntensidadFluorescencia\\AutoClassArticle\\SourceImages",
#   type = "gif",
#   clean = TRUE
# )

#Predict the PCA of new incomming data
SP<-predict(CD.pca,ParData)
SP<-data.frame(SP)

#Find the distance between the centroid of the stages to the predicted stage. Pythagoras theorem
Ook<-sqrt((SP$PC1-OokCen$PC1)^2
          +(SP$PC2-OocCen$PC2)^2
          +(SP$PC3-OokCen$PC3)^2
          +(SP$PC4-OokCen$PC4)^2
          +(SP$PC5-OokCen$PC5)^2
          +(SP$PC6-OokCen$PC6)^2
          +(SP$PC7-OokCen$PC7)^2
          +(SP$PC8-OokCen$PC8)^2
          +(SP$PC9-OokCen$PC9)^2
          +(SP$PC10-OokCen$PC10)^2)
T1<-sqrt((SP$PC1-T1Cen$PC1)^2
         +(SP$PC2-T1Cen$PC2)^2
         +(SP$PC3-T1Cen$PC3)^2
         +(SP$PC4-T1Cen$PC4)^2
         +(SP$PC5-T1Cen$PC5)^2
         +(SP$PC6-T1Cen$PC6)^2
         +(SP$PC7-T1Cen$PC7)^2
         +(SP$PC8-T1Cen$PC8)^2
         +(SP$PC9-T1Cen$PC9)^2
         +(SP$PC10-T1Cen$PC10)^2)
T2<-sqrt((SP$PC1-T2Cen$PC1)^2
         +(SP$PC2-T2Cen$PC2)^2
         +(SP$PC3-T2Cen$PC3)^2
         +(SP$PC4-T2Cen$PC4)^2
         +(SP$PC5-T2Cen$PC5)^2
         +(SP$PC6-T2Cen$PC6)^2
         +(SP$PC7-T2Cen$PC7)^2
         +(SP$PC8-T2Cen$PC8)^2
         +(SP$PC9-T2Cen$PC9)^2
         +(SP$PC10-T2Cen$PC10)^2)
T3<-sqrt((SP$PC1-T3Cen$PC1)^2
         +(SP$PC2-T3Cen$PC2)^2
         +(SP$PC3-T3Cen$PC3)^2
         +(SP$PC4-T3Cen$PC4)^2
         +(SP$PC5-T3Cen$PC5)^2
         +(SP$PC6-T3Cen$PC6)^2
         +(SP$PC7-T3Cen$PC7)^2
         +(SP$PC8-T3Cen$PC8)^2
         +(SP$PC9-T3Cen$PC9)^2
         +(SP$PC10-T3Cen$PC10)^2)
T4<-sqrt((SP$PC1-T4Cen$PC1)^2
         +(SP$PC2-T4Cen$PC2)^2
         +(SP$PC3-T4Cen$PC3)^2
         +(SP$PC4-T4Cen$PC4)^2
         +(SP$PC5-T4Cen$PC5)^2
         +(SP$PC6-T4Cen$PC6)^2
         +(SP$PC7-T4Cen$PC7)^2
         +(SP$PC8-T4Cen$PC8)^2
         +(SP$PC9-T4Cen$PC9)^2
         +(SP$PC10-T4Cen$PC10)^2)
T5<-sqrt((SP$PC1-T5Cen$PC1)^2
         +(SP$PC2-T5Cen$PC2)^2
         +(SP$PC3-T5Cen$PC3)^2
         +(SP$PC4-T5Cen$PC4)^2
         +(SP$PC5-T5Cen$PC5)^2
         +(SP$PC6-T5Cen$PC6)^2
         +(SP$PC7-T5Cen$PC7)^2
         +(SP$PC8-T5Cen$PC8)^2
         +(SP$PC9-T5Cen$PC9)^2
         +(SP$PC10-T5Cen$PC10)^2)
Ooc<-sqrt((SP$PC1-OocCen$PC1)^2
          +(SP$PC2-OocCen$PC2)^2
          +(SP$PC3-OocCen$PC3)^2
          +(SP$PC4-OocCen$PC4)^2
          +(SP$PC5-OocCen$PC5)^2
          +(SP$PC6-OocCen$PC6)^2
          +(SP$PC7-OocCen$PC7)^2
          +(SP$PC8-OocCen$PC8)^2
          +(SP$PC9-OocCen$PC9)^2
          +(SP$PC10-OocCen$PC10)^2)

#Find the minimum distance from a stage.
DistToStage<-data.frame(distance=rbind(Ook,T1,T2,T3,T4,T5,Ooc))
#PredictedStageIndex<-which.min(DistToStage$distance)
PredictedStage<-apply(DistToStage,2,function(x)rownames(DistToStage)[which.min(x)])
#PredictedStageIndex
PredictedStage

#ET<-Sys.time()
#Time<-ET-ST

# Plot parasite stages descriptors
# Stg<-factor(ClassData$Stage,levels=c("Ookinete","Took_1","Took_2","Took_3","Took_4","Took_5","Oocyst"))
# myCol<-c("#FF5555","#FFd738","#FFFF45","#99CC00","#99CCFF","#6088fe","#CC99FF")
# par(mar=c(5,6,4,5.4))
# library(vioplot)
# vioplot(ParArea~Stg,
#         data=ClassData,
#         col=myCol,
#         xlab="Stages",
#         ylab=expression("Parasite area"~(mu~m^{2})),
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Perim~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Parasite perimeter"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Circ~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab="Parasite circularity",
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Eccentricity~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab="Parasite eccentricity",
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(LinEcc~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Parasite focal point"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Mayor~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Parasite semi-mayor axis"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Minor~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Parasite semi-minor axis"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(NucArea~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Nucleus area"~(mu~m^{2})),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(NucPos~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Nucleus position"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(PigArea~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Pigment area"~(mu~m^{2})),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(PigSpots~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Number of pigment spots"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(PigPos~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Pigment position"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(SkLngth~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Skelleton length"~(mu~m^{2})),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(SkBrch~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Number of branches in skelleton"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(SkJun~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Number of junctions in skelleton"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(AR~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Mayor axis/minor axis"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Round~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Roundness"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Solidity~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Solidity"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(Feret~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Feret's diameter"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(BBLngth~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Bounding box length"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(BBWdth~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Bounding box width"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(BBLoBBW~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Bounding box length over width"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(DCTB~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Distance from the parasite's centroid to the averaged branches"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(DCTJ~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Distance from the parasite's centroid to the junction"~(mu~m)),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)
# vioplot(SkLoSkB~Stg,
#         data=ClassData,
#         xlab="Stages",
#         ylab=expression("Skeleton length/number of branches"),
#         col=myCol,
#         cex.lab=1.4,
#         cex.axis=1.2)


# boxplot(ClassData$ParArea~Stg,
#         notch=TRUE,
#         boxwex=0.8,
#         xlab="Stages",
#         ylab=expression("Parasite area"~(mu~m^{2})),
#         col=myCol,
#         lwd=1.4,
#         whisklwd=2.5,
#         boxlwd=2.5,
#         staplelwd=2.5,
#         outlwd=2.5,
#         cex.lab=1.4,
#         cex.axis=1.2)
# stripchart(SkBrch~Stg,
#            data=ClassData,
#            method="jitter",
#            jitter=0.26,
#            vertical=TRUE,
#            pch=20,
#            col=myCol,
#            xlab="Stages",
#            ylab=expression("Number of branches in skelleton"),
#            cex.lab=1.4,
#            cex.axis=1.2)

# Comparison between stages ANOVA/TukeyHSD
# ParAreaA<-aov(ParArea~Stage,data=ClassData)
# summary(ParAreaA)
# ParAreaT<-TukeyHSD(ParAreaA)
# plot(ParAreaT, las=2)
# print(ParAreaT)
# ResParArea<-data.frame(ParAreaT$Stage)
# ResParArea["p.adj"]
# 
# PerimA<-aov(Perim~Stage,data=ClassData)
# summary(PerimA)
# PerimT<-TukeyHSD(PerimA)
# plot(PerimT, las=2)
# print(PerimT)
# ResPerim<-data.frame(PerimT$Stage)
# ResPerim["p.adj"]
# 
# CircA<-aov(Circ~Stage,data=ClassData)
# summary(CircA)
# CircT<-TukeyHSD(CircA)
# plot(CircT, las=2)
# print(CircT)
# ResCirc<-data.frame(CircT$Stage)
# ResCirc["p.adj"]
# 
# EccentricityA<-aov(Eccentricity~Stage,data=ClassData)
# summary(EccentricityA)
# EccentricityT<-TukeyHSD(EccentricityA)
# plot(EccentricityT, las=2)
# print(EccentricityT)
# ResEccentricity<-data.frame(EccentricityT$Stage)
# ResEccentricity["p.adj"]
# 
# LinEccA<-aov(LinEcc~Stage,data=ClassData)
# summary(LinEccA)
# LinEccT<-TukeyHSD(LinEccA)
# plot(LinEccT, las=2)
# print(LinEccT)
# ResLinEcc<-data.frame(LinEccT$Stage)
# ResLinEcc["p.adj"]
# 
# MayorA<-aov(Mayor~Stage,data=ClassData)
# summary(MayorA)
# MayorT<-TukeyHSD(MayorA)
# plot(MayorT, las=2)
# print(MayorT)
# ResMayor<-data.frame(MayorT$Stage)
# ResMayor["p.adj"]
# 
# MinorA<-aov(Minor~Stage,data=ClassData)
# summary(MinorA)
# MinorT<-TukeyHSD(MinorA)
# plot(MinorT, las=2)
# print(MinorT)
# ResMinor<-data.frame(MinorT$Stage)
# ResMinor["p.adj"]
# 
# SkLngthA<-aov(SkLngth~Stage,data=ClassData)
# summary(SkLngthA)
# SkLngthT<-TukeyHSD(SkLngthA)
# plot(SkLngthT, las=2)
# print(SkLngthT)
# ResSkLngth<-data.frame(SkLngthT$Stage)
# ResSkLngth["p.adj"]
# 
# SkBrchA<-aov(SkBrch~Stage,data=ClassData)
# summary(SkBrchA)
# SkBrchT<-TukeyHSD(SkBrchA)
# plot(SkBrchT, las=2)
# print(SkBrchT)
# ResSkBrch<-data.frame(SkBrchT$Stage)
# ResSkBrch["p.adj"]
# 
# SkJunA<-aov(SkJun~Stage,data=ClassData)
# summary(SkJunA)
# SkJunT<-TukeyHSD(SkJunA)
# plot(SkJunT, las=2)
# print(SkJunT)
# ResSkJun<-data.frame(SkJunT$Stage)
# ResSkJun["p.adj"]
# 
# NucAreaA<-aov(NucArea~Stage,data=ClassData)
# summary(NucAreaA)
# NucAreaT<-TukeyHSD(NucAreaA)
# plot(NucAreaT, las=2)
# print(NucAreaT)
# ResNucArea<-data.frame(NucAreaT$Stage)
# ResNucArea["p.adj"]
# 
# NucPosA<-aov(NucPos~Stage,data=ClassData)
# summary(NucPosA)
# NucPosT<-TukeyHSD(NucPosA)
# plot(NucPosT, las=2)
# print(NucPosT)
# ResNucPos<-data.frame(NucPosT$Stage)
# ResNucPos["p.adj"]
# 
# PigPosA<-aov(PigPos~Stage,data=ClassData)
# summary(PigPosA)
# PigPosT<-TukeyHSD(PigPosA)
# plot(PigPosT, las=2)
# print(PigPosT)
# ResPigPos<-data.frame(PigPosT$Stage)
# ResPigPos["p.adj"]
# 
# PigAreaA<-aov(PigArea~Stage,data=ClassData)
# summary(PigAreaA)
# PigAreaT<-TukeyHSD(PigAreaA)
# plot(PigAreaT, las=2)
# print(PigAreaT)
# ResPigArea<-data.frame(PigAreaT$Stage)
# ResPigArea["p.adj"]
# 
# PigSpotsA<-aov(PigSpots~Stage,data=ClassData)
# summary(PigSpotsA)
# PigSpotsT<-TukeyHSD(PigSpotsA)
# plot(PigSpotsT, las=2)
# print(PigSpotsT)
# ResPigSpots<-data.frame(PigSpotsT$Stage)
# ResPigSpots["p.adj"]

# # Comparison between stages Kruskall-Wallis/Dunn
# library(FSA)
# ParAreaKW<-kruskal.test(ParArea~Stage,data=ClassData)
# ParAreaKW
# ParAreaD<-dunnTest(ParArea~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResParArea<-data.frame(ParAreaD[["res"]][["Comparison"]],ParAreaD[["res"]][["P.adj"]])
# ResParArea
# 
# PerimKW<-kruskal.test(Perim~Stage,data=ClassData)
# PerimKW
# PerimD<-dunnTest(Perim~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResPerim<-data.frame(PerimD[["res"]][["Comparison"]],PerimD[["res"]][["P.adj"]])
# ResPerim
# 
# CircKW<-kruskal.test(Circ~Stage,data=ClassData)
# CircKW
# CircD<-dunnTest(Circ~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResCirc<-data.frame(CircD[["res"]][["Comparison"]],CircD[["res"]][["P.adj"]])
# ResCirc
# 
# EccentricityKW<-kruskal.test(Eccentricity~Stage,data=ClassData)
# EccentricityKW
# EccentricityD<-dunnTest(Eccentricity~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResEccentricity<-data.frame(EccentricityD[["res"]][["Comparison"]],EccentricityD[["res"]][["P.adj"]])
# ResEccentricity
# 
# LinEccKW<-kruskal.test(LinEcc~Stage,data=ClassData)
# LinEccKW
# LinEccD<-dunnTest(LinEcc~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResLinEcc<-data.frame(LinEccD[["res"]][["Comparison"]],LinEccD[["res"]][["P.adj"]])
# ResLinEcc
# 
# MayorKW<-kruskal.test(Mayor~Stage,data=ClassData)
# MayorKW
# MayorD<-dunnTest(Mayor~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResMayor<-data.frame(MayorD[["res"]][["Comparison"]],MayorD[["res"]][["P.adj"]])
# ResMayor
# 
# MinorKW<-kruskal.test(Minor~Stage,data=ClassData)
# MinorKW
# MinorD<-dunnTest(Minor~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResMinor<-data.frame(MinorD[["res"]][["Comparison"]],MinorD[["res"]][["P.adj"]])
# ResMinor
# 
# SkLngthKW<-kruskal.test(SkLngth~Stage,data=ClassData)
# SkLngthKW
# SkLngthD<-dunnTest(SkLngth~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResSkLngth<-data.frame(SkLngthD[["res"]][["Comparison"]],SkLngthD[["res"]][["P.adj"]])
# ResSkLngth
# 
# SkBrchKW<-kruskal.test(SkBrch~Stage,data=ClassData)
# SkBrchKW
# SkBrchD<-dunnTest(SkBrch~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResSkBrch<-data.frame(SkBrchD[["res"]][["Comparison"]],SkBrchD[["res"]][["P.adj"]])
# ResSkBrch
# 
# SkJunKW<-kruskal.test(SkJun~Stage,data=ClassData)
# SkJunKW
# SkJunD<-dunnTest(SkJun~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResSkJun<-data.frame(SkJunD[["res"]][["Comparison"]],SkJunD[["res"]][["P.adj"]])
# ResSkJun
# 
# NucAreaKW<-kruskal.test(NucArea~Stage,data=ClassData)
# NucAreaKW
# NucAreaD<-dunnTest(NucArea~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResNucArea<-data.frame(NucAreaD[["res"]][["Comparison"]],NucAreaD[["res"]][["P.adj"]])
# ResNucArea
# 
# NucPosKW<-kruskal.test(NucPos~Stage,data=ClassData)
# NucPosKW
# NucPosD<-dunnTest(NucPos~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResNucPos<-data.frame(NucPosD[["res"]][["Comparison"]],NucPosD[["res"]][["P.adj"]])
# ResNucPos
# 
# PigPosKW<-kruskal.test(PigPos~Stage,data=ClassData)
# PigPosKW
# PigPosD<-dunnTest(PigPos~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResPigPos<-data.frame(PigPosD[["res"]][["Comparison"]],PigPosD[["res"]][["P.adj"]])
# ResPigPos
# 
# PigAreaKW<-kruskal.test(PigArea~Stage,data=ClassData)
# PigAreaKW
# PigAreaD<-dunnTest(PigArea~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResPigArea<-data.frame(PigAreaD[["res"]][["Comparison"]],PigAreaD[["res"]][["P.adj"]])
# ResPigArea
# 
# PigSpotsKW<-kruskal.test(PigSpots~Stage,data=ClassData)
# PigSpotsKW
# PigSpotsD<-dunnTest(PigSpots~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResPigSpots<-data.frame(PigSpotsD[["res"]][["Comparison"]],PigSpotsD[["res"]][["P.adj"]])
# ResPigSpots
# 
# ARKW<-kruskal.test(AR~Stage,data=ClassData)
# ARKW
# ARD<-dunnTest(AR~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResAR<-data.frame(ARD[["res"]][["Comparison"]],ARD[["res"]][["P.adj"]])
# ResAR
# 
# RoundKW<-kruskal.test(Round~Stage,data=ClassData)
# RoundKW
# RoundD<-dunnTest(Round~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResRound<-data.frame(RoundD[["res"]][["Comparison"]],RoundD[["res"]][["P.adj"]])
# ResRound
# 
# SolidityKW<-kruskal.test(Solidity~Stage,data=ClassData)
# SolidityKW
# SolidityD<-dunnTest(Solidity~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResSolidity<-data.frame(SolidityD[["res"]][["Comparison"]],SolidityD[["res"]][["P.adj"]])
# ResSolidity
# 
# FeretKW<-kruskal.test(Feret~Stage,data=ClassData)
# FeretKW
# FeretD<-dunnTest(Feret~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResFeret<-data.frame(FeretD[["res"]][["Comparison"]],FeretD[["res"]][["P.adj"]])
# ResFeret
# 
# BBLngthKW<-kruskal.test(BBLngth~Stage,data=ClassData)
# BBLngthKW
# BBLngthD<-dunnTest(BBLngth~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResBBLngth<-data.frame(BBLngthD[["res"]][["Comparison"]],BBLngthD[["res"]][["P.adj"]])
# ResBBLngth
# 
# BBWdthKW<-kruskal.test(BBWdth~Stage,data=ClassData)
# BBWdthKW
# BBWdthD<-dunnTest(BBWdth~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResBBWdth<-data.frame(BBWdthD[["res"]][["Comparison"]],BBWdthD[["res"]][["P.adj"]])
# ResBBWdth
# 
# BBLoBBWKW<-kruskal.test(BBLoBBW~Stage,data=ClassData)
# BBLoBBWKW
# BBLoBBWD<-dunnTest(BBLoBBW~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResBBLoBBW<-data.frame(BBLoBBWD[["res"]][["Comparison"]],BBLoBBWD[["res"]][["P.adj"]])
# ResBBLoBBW
# 
# DCTBKW<-kruskal.test(DCTB~Stage,data=ClassData)
# DCTBKW
# DCTBD<-dunnTest(DCTB~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResDCTB<-data.frame(DCTBD[["res"]][["Comparison"]],DCTBD[["res"]][["P.adj"]])
# ResDCTB
# 
# DCTJKW<-kruskal.test(DCTJ~Stage,data=ClassData)
# DCTJD<-dunnTest(DCTJ~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResDCTJ<-data.frame(DCTJD[["res"]][["Comparison"]],DCTJD[["res"]][["P.adj"]])
# 
# DCTJKW<-kruskal.test(DCTJ~Stage,data=ClassData)
# DCTJD<-dunnTest(DCTJ~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResDCTJ<-data.frame(DCTJD[["res"]][["Comparison"]],DCTJD[["res"]][["P.adj"]])
# 
# SkLoSkBKW<-kruskal.test(SkLoSkB~Stage,data=ClassData)
# SkLoSkBD<-dunnTest(SkLoSkB~Stage,data=ClassData,method="holm",two.sided=TRUE)
# ResSkLoSkB<-data.frame(SkLoSkBD[["res"]][["Comparison"]],SkLoSkBD[["res"]][["P.adj"]])
# 
# 
# pVal<-cbind(ResParArea$ParAreaD...res......P.adj...,
#             ResPerim$PerimD...res......P.adj...,
#             ResCirc$CircD...res......P.adj...,
#             ResRound$RoundD...res......P.adj...,
#             ResSolidity$SolidityD...res......P.adj...,
#             ResAR$ARD...res......P.adj...,
#             ResEccentricity$EccentricityD...res......P.adj...,
#             ResLinEcc$LinEccD...res......P.adj...,
#             ResMayor$MayorD...res......P.adj...,
#             ResMinor$MinorD...res......P.adj...,
#             ResFeret$FeretD...res......P.adj...,
#             ResBBLngth$BBLngthD...res......P.adj...,
#             ResBBWdth$BBWdthD...res......P.adj...,
#             ResBBLoBBW$BBLoBBWD...res......P.adj...,
#             ResSkLngth$SkLngthD...res......P.adj...,
#             ResSkBrch$SkBrchD...res......P.adj...,
#             ResSkJun$SkJunD...res......P.adj...,
#             ResSkLoSkB$SkLoSkBD...res......P.adj...,
#             ResDCTB$DCTBD...res......P.adj...,
#             ResDCTJ$DCTJD...res......P.adj...,
#             ResNucArea$NucAreaD...res......P.adj...,
#             ResNucPos$NucPosD...res......P.adj...,
#             ResPigArea$PigAreaD...res......P.adj...,
#             ResPigSpots$PigSpotsD...res......P.adj...,
#             ResPigPos$PigPosD...res......P.adj...)
# pVal<-data.frame(pVal)

#Evaluate the PCA
# library(factoextra)
# var<-get_pca_var(CD.pca)
# library(corrplot)
# corrplot(var$cos2)
# head(var$contrib)
# fviz_pca_var(CD.pca, col.var = "cos2",
#              gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
#              repel = TRUE # Avoid text overlapping
# )
# corrplot(var$contrib,is.corr=FALSE)
# fviz_contrib(CD.pca, choice = "var", axes = 1, top = 10)
# fviz_contrib(CD.pca, choice = "var", axes = 2, top = 10)
# fviz_contrib(CD.pca, choice = "var", axes = 1:3, top = 10)
# set.seed(123)
# my.cont.var <- rnorm(15)
# fviz_pca_var(CD.pca, col.var = my.cont.var,
#              gradient.cols = c("blue", "yellow", "red"),
#              legend.title = "Cont.Var")
# res.km <- kmeans(var$coord, centers = 4, nstart = 25)
# grp <- as.factor(res.km$cluster)
# fviz_pca_var(CD.pca, col.var = grp,
#              palette = c("#0073C2FF", "#EFC000FF", "#868686FF", "#ddee56FF"),
#              legend.title = "Cluster")
# SiPa <- get_pca_ind(CD.pca)
# head(SiPa$coord)
# head(SiPa$cos2)
# head(SiPa$contrib)
# fviz_pca_ind(CD.pca,col.ind=clrs, groups=CD.stages)
# fviz_pca_ind(CD.pca, col.ind = "cos2",
#              gradient.cols = clrs)
# fviz_cos2(CD.pca, choice = "ind")
# fviz_contrib(CD.pca, choice = "ind", axes = 1:2)
# fviz_pca_ind(CD.pca,
#              geom.ind = "point", # show points only (nbut not "text")
#              col.ind = CD.stages, # color by groups
#              palette = c("#CC99FF","#FF0000","#FFCC00","#FFFF00","#99CC00","#99CCFF","#3366FF"),
#              addEllipses = TRUE, # Concentration ellipses
#              legend.title = "Groups")

#Other methods for classification

#T-SNE algorithm for parasite classification
# library(Rtsne)
# sd<-4
# set.seed(sd)
# prplx<-30
# CD.tsne <- Rtsne(ClassData,#PCA=FALSE,
#                  dims = 3,
#                  perplexity=prplx,
#                  verbose=TRUE,
#                  max_iter = 1000,
#                  check_duplicates=FALSE)
# plot(CD.tsne$Y,t='n', main=prplx)
# text(CD.tsne$Y, col=clrs)
# require(rgl)
# plot3d(CD.tsne$Y, col=clrs,size=8)

#Heat map analysis
# CD.heat<-as.matrix(CD.data)
# CD.heatLog<-as.matrix(CD.dataLog)
# rownames(CD.heatLog)<-CD.stages
# colnames(CD.heatLog)
# rownames(CD.heat)<-CD.stages
# colnames(CD.heat)
# heatmap(CD.heat, RowSideColors=clrs, col=cm.colors(256))
# heatmap(CD.heat[,1:2], RowSideColors=clrs, col=cm.colors(256))
# heatmap(CD.heat[,-1], RowSideColors=clrs, col=cm.colors(256))
# heatmap(CD.heat[,c(1,2,3,4,5,6,7,8,9)], RowSideColors=clrs, col=terrain.colors(256),Colv=NA)
# heatmap(CD.heat[,c(2,3,5,6,7,8)], RowSideColors=clrs, col=cm.colors(256),Colv=NA)
# heatmap(CD.heat[,c(2,3,6,8)], RowSideColors=clrs, col=cm.colors(256),Colv=NA)
# heatmap(CD.heat[,c(2,3,7,8)], RowSideColors=clrs, col=terrain.colors(256),Colv=NA)
# heatmap(CD.heatLog[,c(1,2,3,5,6,7,8,9)], RowSideColors=clrs, col=terrain.colors(256))
# heatmap(CD.heat[,c(1,2,3,5,6,7,8,9)], RowSideColors=clrs, col=terrain.colors(256))

#CD.K<-kmeans(CD.heat,3)
# library(fpc)
# CD.K<-kmeans(CD.heat[,c(1,2,3,5,6,8,9)],7)
# plotcluster(CD.data,CD.K$cluster)
# CD.K<-kmeans(CD.heat,7)
# plotcluster(CD.data,CD.K$cluster)
# 
# which(CD.K$cluster==1)
# which(CD.K$cluster==2)
# which(CD.K$cluster==3)
# which(CD.K$cluster==4)
# which(CD.K$cluster==5)
# which(CD.K$cluster==6)
# which(CD.K$cluster==7)
#
#
#Heriarchy analysis
# CD.h<-hclust(dist(CD.data))
# plot(CD.h,hang=-1)
# CD.hcut<-cutree(CD.h,7)
# table(CD.hcut, ClassData$Stage)
# 
# CD.h<-hclust(dist(CD.data[,c(2,3,7,8)]))
# plot(CD.h,hang=-1)
# CD.hcut<-cutree(CD.h,7)
# table(CD.hcut, ClassData$Stage)
# 
# CD.h<-hclust(dist(CD.data[,c(1,2,3,7,8,10,12,13)]))
# plot(CD.h,hang=-1)
# CD.hcut<-cutree(CD.h,7)
# table(CD.hcut, ClassData$Stage)
#
#
#Other type of analysis (PCA clustering)
# library(adegenet)
# DS<-find.clusters(CD.data, max.n.clust=7)
# table(CD.stages,DS$grp)
# table.value(table(CD.stages,DS$grp))

#DAPC
# dapc1<-dapc(CD.data, DS$grp)
# myCol<-c("red","green","blue")
# scatter(dapc1, scree.da=FALSE, bg="white", pch=20, cstar=0, col=clrs, solid=.4, cex=3,clab=0, leg=TRUE, txt.leg=paste("Cluster",1:7))
# dapc2<-dapc(CD.data, CD.stages)
# scatter(dapc2,scree.da=FALSE,bg="white",pch=20,cstar=0,col=clrs,solid=.4,cex=3,clab=0,leg=TRUE)

# Mean of the descriptors per stage
# OokM<-subset(ClassData, Stage=="Ookinete")
# T1M<-subset(ClassData, Stage=="Took_1")
# T2M<-subset(ClassData, Stage=="Took_2")
# T3M<-subset(ClassData, Stage=="Took_3")
# T4M<-subset(ClassData, Stage=="Took_4")
# T5M<-subset(ClassData, Stage=="Took_5")
# OocM<-subset(ClassData, Stage=="Oocyst")
# 
# OokM<-colMeans(OokM[sapply(OokM,is.numeric)])
# T1M<-colMeans(T1M[sapply(T1M,is.numeric)])
# T2M<-colMeans(T2M[sapply(T2M,is.numeric)])
# T3M<-colMeans(T3M[sapply(T3M,is.numeric)])
# T4M<-colMeans(T4M[sapply(T4M,is.numeric)])
# T5M<-colMeans(T5M[sapply(T5M,is.numeric)])
# OocM<-colMeans(OocM[sapply(OocM,is.numeric)])
# 
# StMeans<-data.frame(OokM,T1M,T2M,T3M,T4M,T5M,OocM)
