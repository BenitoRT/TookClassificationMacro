#This scipt adds the parasite measurements to the training database.

# setwd("C:\\ImageJ\\macros\\TCM-R")

#Import Classification Data table and Parasite Measurement table
ClassData<-read.csv("ClassData.csv")
ParMeas<-read.csv("ParMeas.csv")

#Create the data frame of the Parasite Measurements
ParData<-data.frame(ParArea=ParMeas[2,3],
                    NucPos=ParMeas[3,4],
                    NucArea=ParMeas[3,3],
                    PigPos=ParMeas[4,4],
                    PigArea=ParMeas[4,3],
                    PigSpots=ParMeas[4,34],
                    Perim=ParMeas[2,12],
                    Circ=ParMeas[2,20],
                    AR=ParMeas[2,29],
                    Round=ParMeas[2,30],
                    Solidity=ParMeas[2,31],
                    Mayor=ParMeas[2,17],
                    Minor=ParMeas[2,18],
                    SkLngth=ParMeas[5,35],
                    SkBrch=SkBrch,
                    SkJun=ParMeas[7,37],
                    Feret=ParMeas[2,21],
                    #MinF=ParMeas[2,27],
                    BBLngth=ParMeas[1,32],
                    BBWdth=ParMeas[1,33],
                    DCTB=DistCenToBrch,
                    DCTJ=DistCenToJun,
                    Stage=ParMeas[2,38])


#Add the new parasite to the training data frame and save it
ClassData<-rbind(ClassData, ParData)
write.csv(ClassData, file="ClassData.csv", row.names=FALSE)
